export default async (req) => {
  if (req.method !== "POST") return new Response(JSON.stringify({ error: "Método não permitido." }), { status: 405, headers: { "Content-Type": "application/json" } });
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return new Response(JSON.stringify({ error: "A chave GEMINI_API_KEY não foi configurada no Netlify." }), { status: 500, headers: { "Content-Type": "application/json" } });
  try {
    const body = await req.json();
    const subject = String(body.subject || "Conversa geral").slice(0, 100);
    const messages = Array.isArray(body.messages) ? body.messages.slice(-20) : [];
    const contents = messages.map(m => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: Array.isArray(m.parts) ? m.parts : [{ text: String(m.text || "") }]
    }));
    const systemInstruction = {
      parts: [{ text: `Você é a ZELLOX IA, uma assistente educacional amigável que responde em português brasileiro. Matéria selecionada: ${subject}. Explique com clareza, organize respostas com títulos e listas quando útil, mostre cálculos passo a passo e ajude o estudante a aprender. Se a pergunta não for da matéria selecionada, ainda assim tente ajudar. Não afirme ser infalível; reconheça incertezas e corrija possíveis erros. Não peça dados pessoais, senhas ou informações privadas.` }]
    };
    const endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent";
    const upstream = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": apiKey },
      body: JSON.stringify({ systemInstruction, contents, generationConfig: { temperature: 0.7, maxOutputTokens: 2048 } })
    });
    const result = await upstream.json();
    if (!upstream.ok) {
      const message = result?.error?.message || "O Gemini recusou a solicitação. Verifique a chave, o modelo e os limites da API.";
      return new Response(JSON.stringify({ error: message }), { status: upstream.status, headers: { "Content-Type": "application/json" } });
    }
    const reply = result?.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("") || "Não consegui gerar uma resposta.";
    return new Response(JSON.stringify({ reply }), { status: 200, headers: { "Content-Type": "application/json" } });
  } catch (error) {
    return new Response(JSON.stringify({ error: "Erro interno ao processar a mensagem." }), { status: 500, headers: { "Content-Type": "application/json" } });
  }
};